# Implementation Plan: True Vanilla Minecraft Audio Asset Download & Playback

Replace procedural audio synthesis with genuine official Minecraft Bedrock `.ogg` audio files downloaded directly into `public/vanilla_sounds/` so every sound event plays the real in-game audio recording.

---

## 1. Download Genuine Bedrock Audio Files (`public/vanilla_sounds/`)
- Download authentic Minecraft Bedrock OGG sound files into `public/vanilla_sounds/`:
  - Block sounds (`stone`, `wood`, `dirt`, `glass`, `anvil`, `amethyst`, `grass`)
  - Items & Actions (`orb`, `bow`, `eat`, `drink`, `pop`, `door_open`, `chest_open`, `chest_closed`)
  - Explosions & Combat (`explode1`, `explode2`, `hit`, `bowhit`, `crossbow`)
  - Mobs (`zombie`, `skeleton`, `creeper_primed`, `dragon`, `villager`, `cow`, `pig`)
  - UI (`click`, `press`, `pop`)
- Generate mapping registry `src/data/vanillaAudioFileMap.json` linking sound identifiers to the actual downloaded `.ogg` file paths.

---

## 2. Connect `soundEngine.ts` to True Audio Files
- Update `soundEngine.ts` to load and decode the real `.ogg` audio files from `/vanilla_sounds/...`.
- Support speed/pitch playback rate modifications (`source.playbackRate.value = pitch`) and volume matching Bedrock `sounds.json` specifications.
- Custom replacement support: uploading custom `.ogg` files in the Sounds studio overrides the vanilla `.ogg` audio file and bundles into `.mcpack`.

---

## 3. Verification
- Click test sound events across blocks, items, mobs, and UI in the **Sounds** tab to confirm genuine authentic Minecraft audio is playing.
- Verify custom imported `.ogg` audio overrides play correctly.
