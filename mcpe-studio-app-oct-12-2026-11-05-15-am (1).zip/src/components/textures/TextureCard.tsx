import React, { useEffect, useState, useMemo } from 'react';
import { Check, Box, Sword, Sparkles, Layout, Cloud, Eye } from 'lucide-react';
import { TextureSlot } from '../../types';
import { textureUrlCache } from '../../utils/lruCache';
import {
  getVanillaTextureUrl,
  getVanillaTextureFallbackUrl,
  getProceduralVanillaReferenceUrl,
} from '../../utils/vanillaTextureGenerator';

interface TextureCardProps {
  slot: TextureSlot;
  isSelected: boolean;
  isCustomized: boolean;
  customImageData?: Uint8Array;
  onSelect: (slot: TextureSlot) => void;
}

export const TextureCard: React.FC<TextureCardProps> = ({
  slot,
  isSelected,
  isCustomized,
  customImageData,
  onSelect,
}) => {
  const [thumbUrl, setThumbUrl] = useState<string | null>(null);

  // Generate or retrieve thumbnail
  useEffect(() => {
    if (isCustomized && customImageData && customImageData.length > 0) {
      const cachedUrl = textureUrlCache.set(slot.path, customImageData);
      setThumbUrl(cachedUrl);
    } else {
      setThumbUrl(null);
    }
  }, [customImageData, isCustomized, slot.path]);

  // Real vanilla .png texture URL saved in project
  const vanillaUrl = useMemo(() => getVanillaTextureUrl(slot.path), [slot.path]);
  const [imgSrc, setImgSrc] = useState<string>(vanillaUrl);
  const [imgFailed, setImgFailed] = useState<boolean>(false);

  useEffect(() => {
    setImgSrc(vanillaUrl);
    setImgFailed(false);
  }, [vanillaUrl]);

  const handleImageError = () => {
    if (imgSrc === vanillaUrl) {
      // Try official Mojang GitHub raw fallback
      setImgSrc(getVanillaTextureFallbackUrl(slot.path));
    } else {
      // If both network/static fail, fall back to procedural
      setImgFailed(true);
    }
  };

  // Fallback procedural vanilla reference url for viewing
  const referenceUrl = useMemo(() => {
    return getProceduralVanillaReferenceUrl(
      slot.id,
      slot.sampleColor || '#64748B',
      slot.recommendedWidth,
      slot.recommendedHeight
    );
  }, [slot.id, slot.sampleColor, slot.recommendedWidth, slot.recommendedHeight]);

  const getCategoryIcon = () => {
    switch (slot.category) {
      case 'blocks':
        return <Box className="w-3.5 h-3.5" />;
      case 'items':
        return <Sword className="w-3.5 h-3.5" />;
      case 'entity':
        return <Sparkles className="w-3.5 h-3.5" />;
      case 'ui':
        return <Layout className="w-3.5 h-3.5" />;
      case 'environment':
        return <Cloud className="w-3.5 h-3.5" />;
      default:
        return <Box className="w-3.5 h-3.5" />;
    }
  };

  return (
    <div
      onClick={() => onSelect(slot)}
      className={`group relative p-3 rounded-xl border cursor-pointer transition-all flex flex-col justify-between ${
        isSelected
          ? 'bg-[#162232] border-sky-400 shadow-[0_0_20px_rgba(56,189,248,0.2)] ring-1 ring-sky-400/30'
          : isCustomized
          ? 'bg-[#121E24] border-emerald-500/40 hover:border-emerald-400 hover:shadow-[0_0_15px_rgba(16,185,129,0.1)]'
          : 'bg-[#101722] border-[#1C2738] hover:border-slate-600 hover:bg-[#131D2A]'
      }`}
    >
      <div className="flex items-start gap-3">
        {/* Preview Thumbnail Box with pixel checkerboard */}
        <div
          className="w-14 h-14 rounded-lg bg-[#090D14] border border-[#223044] shrink-0 flex items-center justify-center overflow-hidden relative shadow-inner group-hover:scale-105 transition-transform"
          style={{
            backgroundImage: `linear-gradient(45deg, #151D28 25%, transparent 25%),
               linear-gradient(-45deg, #151D28 25%, transparent 25%),
               linear-gradient(45deg, transparent 75%, #151D28 75%),
               linear-gradient(-45deg, transparent 75%, #151D28 75%)`,
            backgroundSize: '10px 10px',
          }}
        >
          {thumbUrl ? (
            <img
              src={thumbUrl}
              alt={slot.name}
              className="w-full h-full object-contain p-1"
              style={{ imageRendering: 'pixelated' }}
            />
          ) : !imgFailed ? (
            <img
              src={imgSrc}
              alt={`${slot.name} vanilla`}
              loading="lazy"
              onError={handleImageError}
              className="w-full h-full object-contain p-1 opacity-90 group-hover:opacity-100 transition-opacity"
              style={{ imageRendering: 'pixelated' }}
            />
          ) : referenceUrl ? (
            <img
              src={referenceUrl}
              alt={`${slot.name} reference`}
              className="w-full h-full object-contain p-1 opacity-80 group-hover:opacity-100 transition-opacity"
              style={{ imageRendering: 'pixelated' }}
            />
          ) : (
            <div
              className="w-8 h-8 rounded flex items-center justify-center text-slate-300"
              style={{ backgroundColor: `${slot.sampleColor || '#38BDF8'}25` }}
            >
              {getCategoryIcon()}
            </div>
          )}

          {/* Reference indicator icon when uncustomized */}
          {!isCustomized && (
            <div
              title="Vanilla Reference (Visual Only)"
              className="absolute bottom-0 right-0 bg-[#0B0F14]/90 px-1 py-0.5 rounded-tl text-[8px] text-slate-400 font-mono"
            >
              <Eye className="w-2.5 h-2.5 text-slate-400 inline mr-0.5" />
            </div>
          )}
        </div>

        {/* Slot Info */}
        <div className="min-w-0 flex-1">
          <div className="flex items-center justify-between gap-1">
            <h4 className="text-xs font-bold text-slate-100 truncate group-hover:text-white flex items-center gap-1.5">
              <span className="truncate">{slot.name}</span>
            </h4>
            {isCustomized ? (
              <span className="flex items-center gap-1 text-[10px] text-emerald-300 font-semibold shrink-0 bg-emerald-500/20 border border-emerald-500/30 px-1.5 py-0.5 rounded-md">
                <Check className="w-3 h-3 text-emerald-400" />
                <span>Custom</span>
              </span>
            ) : (
              <span className="text-[9px] text-slate-400 font-mono shrink-0 bg-[#16202E] border border-[#202E42] px-1.5 py-0.5 rounded">
                Vanilla
              </span>
            )}
          </div>

          {/* Directional face & equipment badge */}
          <div className="flex items-center gap-1.5 mt-0.5">
            {slot.path.includes('_top') && (
              <span className="text-[9px] font-mono font-semibold px-1.5 py-0.2 rounded bg-sky-500/10 text-sky-300 border border-sky-500/20">
                ⬆️ Top Face
              </span>
            )}
            {slot.path.includes('_bottom') && (
              <span className="text-[9px] font-mono font-semibold px-1.5 py-0.2 rounded bg-indigo-500/10 text-indigo-300 border border-indigo-500/20">
                ⬇️ Bottom
              </span>
            )}
            {(slot.path.includes('_front') || slot.path.includes('_face')) && (
              <span className="text-[9px] font-mono font-semibold px-1.5 py-0.2 rounded bg-amber-500/10 text-amber-300 border border-amber-500/20">
                ▶️ Front Face
              </span>
            )}
            {slot.path.includes('_side') && (
              <span className="text-[9px] font-mono font-semibold px-1.5 py-0.2 rounded bg-teal-500/10 text-teal-300 border border-teal-500/20">
                ↔️ Side Face
              </span>
            )}
            {slot.path.includes('_layer_1') && (
              <span className="text-[9px] font-mono font-semibold px-1.5 py-0.2 rounded bg-purple-500/10 text-purple-300 border border-purple-500/20">
                🛡️ Armor Layer 1
              </span>
            )}
            {slot.path.includes('_layer_2') && (
              <span className="text-[9px] font-mono font-semibold px-1.5 py-0.2 rounded bg-fuchsia-500/10 text-fuchsia-300 border border-fuchsia-500/20">
                🛡️ Armor Layer 2
              </span>
            )}
          </div>

          <p className="text-[10px] font-mono text-slate-400 truncate mt-1" title={slot.path}>
            {slot.path}
          </p>

          <p className="text-[11px] text-slate-400 line-clamp-1 mt-1 leading-snug">
            {slot.description}
          </p>
        </div>
      </div>

      {/* Footer dimension & category */}
      <div className="mt-3 pt-2 border-t border-[#1C2738] flex items-center justify-between text-[10px] text-slate-400">
        <span className="capitalize flex items-center gap-1 text-slate-300">
          <span className="text-slate-400">{getCategoryIcon()}</span>
          <span>{slot.category}</span>
        </span>
        <span className="font-mono text-slate-400 bg-[#0A0E14] px-1.5 py-0.5 rounded border border-[#1E293B]">
          {slot.recommendedWidth}×{slot.recommendedHeight}px
        </span>
      </div>
    </div>
  );
};
